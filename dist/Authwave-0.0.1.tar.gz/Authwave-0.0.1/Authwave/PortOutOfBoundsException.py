from Authwave.AuthwaveException import AuthwaveException

class PortOutOfBoundsException(AuthwaveException):
    pass