from Authwave.AuthwaveException import AuthwaveException

class IncompatableRedirectHandlerException(AuthwaveException):
    pass