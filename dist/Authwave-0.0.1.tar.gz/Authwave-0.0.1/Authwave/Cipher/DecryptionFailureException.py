from Authwave.Cipher.CipherException import CipherException

class DecryptionFailureException(CipherException):
    pass