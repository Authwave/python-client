class CipherException(RuntimeError):
    pass