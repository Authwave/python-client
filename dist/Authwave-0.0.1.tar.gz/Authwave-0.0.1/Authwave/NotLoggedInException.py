from Authwave.AuthwaveException import AuthwaveException

class NotLoggedInException(AuthwaveException):
    pass