class RedirectHandler():

    def redirect(self, uri):
        pass