from Authwave.AuthwaveException import AuthwaveException

class InsecureProtocolException(AuthwaveException):
    pass