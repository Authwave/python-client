class AuthwaveException(RuntimeError):
    pass