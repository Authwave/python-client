from Authwave.AuthwaveException import AuthwaveException

class InvalidUserDataSerializationException(AuthwaveException):
    pass