from Authwave.AuthwaveException import AuthwaveException

class ResponseCipherDecryptionException(AuthwaveException):
    pass