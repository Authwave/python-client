from Authwave.AuthwaveException import AuthwaveException

class SessionNotDictLikeException(AuthwaveException):
    pass